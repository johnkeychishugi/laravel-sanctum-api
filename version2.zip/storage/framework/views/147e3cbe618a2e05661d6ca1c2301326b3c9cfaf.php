<html>
<head>
    <title><?php echo e(config('app.name')); ?> | Frontend API's Swagger</title>
    <link href="<?php echo e(asset('swagger/style.css')); ?>" rel="stylesheet">
    <style>
        html
        {
          box-sizing: border-box;
          overflow: -moz-scrollbars-vertical;
          overflow-y: scroll;
        }
        *,
        *:before,
        *:after
        {
          box-sizing: inherit;
        }
    
        body {
          margin:0;
          background: #fafafa;
        }
      </style>
</head>
<body>
<div id="swagger-ui"></div>
<script src="<?php echo e(asset('swagger/jquery-2.1.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('swagger/swagger-bundle.js')); ?>"></script>
<script type="application/javascript">
    const ui = SwaggerUIBundle({
        url: "<?php echo e(asset('swagger/swagger.json')); ?>",
        dom_id: '#swagger-ui',
    });
</script>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel-sanctum-api/resources/views/swagger/index.blade.php ENDPATH**/ ?>